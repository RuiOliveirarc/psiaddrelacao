<div style="background-color: gray"><h1 style="text-align: center">Show</h1></div>

ID:<?php echo e($livro->id_livro); ?><br>
Título:<?php echo e($livro->titulo); ?><br>
Idioma:<?php echo e($livro->idioma); ?><br>

Autor:
<?php $__currentLoopData = $livro->autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php echo e($autor->nome); ?><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


Editora:
<?php $__currentLoopData = $livro->editoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $editora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php echo e($editora->nome); ?><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php /**PATH D:\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>