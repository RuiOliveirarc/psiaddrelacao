ID:{{$livro->idl}}<br>
Título:{{$livro->titulo}}<br>
Idioma:{{$livro->idioma}}