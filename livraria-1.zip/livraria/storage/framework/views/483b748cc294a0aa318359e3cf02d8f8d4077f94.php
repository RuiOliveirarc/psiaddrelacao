<h2>deseja eliminar o autor</h2>
<h2><?php echo e($autor->nome); ?></h2>
<form method="post" action="<?php echo e(route('autores.destroy',['id'=>$autor->id_autor])); ?>">
	<?php echo csrf_field(); ?>
	<?php echo method_field('delete'); ?>
	<input type="submit" name="enviar">
</form>
<?php /**PATH D:\livraria\resources\views/autores/delete.blade.php ENDPATH**/ ?>