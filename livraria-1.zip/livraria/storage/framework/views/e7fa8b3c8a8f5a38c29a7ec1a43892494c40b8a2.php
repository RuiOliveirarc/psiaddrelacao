ID Livro: <?php echo e($edicao->id_livro); ?><br>
ID Editora: <?php echo e($edicao->id_editora); ?><br>
Data: <?php echo e($edicao->data); ?><br>
Observacao: <?php echo e($edicao->observacoes); ?><?php /**PATH D:\psiat4\livraria\resources\views/edicoes/show.blade.php ENDPATH**/ ?>