<h2>deseja eliminar o editora</h2>
<h2><?php echo e($editora->nome); ?></h2>
<form method="post" action="<?php echo e(route('editoras.destroy',['id'=>$editora->id_editora])); ?>">
	<?php echo csrf_field(); ?>
	<?php echo method_field('delete'); ?>
	<input type="submit" name="enviar">
</form><?php /**PATH D:\livraria\resources\views/editoras/delete.blade.php ENDPATH**/ ?>